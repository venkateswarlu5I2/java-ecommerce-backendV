package com.zoho.config;

public class JWT_CONSTANT {
	
	public static final String SECRET_KEY="wpembytrwcvnryxksdbqwjebruyGHyudqgwveytrtrCSnwifoesarjbwe";
	public static final String JWT_HEADER="Authorization";
	
}
