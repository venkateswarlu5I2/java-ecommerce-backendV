package com.zoho.config;

import java.io.IOException;
import java.util.List;

import javax.crypto.SecretKey;
import org.springframework.security.core.Authentication;


import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JwtTokenValidator extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
	        throws ServletException, IOException {
	    
	    // 🔥 LOGIN PATH SKIP - First line lo pettandi
	    if (request.getRequestURI().equals("/sellers/login")) {
	        filterChain.doFilter(request, response);
	        return;
	    }
	    
	    String jwt = request.getHeader("Authorization");
	    
	    // Bearer check + null check
	    if (jwt != null && jwt.startsWith("Bearer ")) {
	        try {
	            jwt = jwt.substring(7);
	            SecretKey key = Keys.hmacShaKeyFor(JWT_CONSTANT.SECRET_KEY.getBytes());
	            Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();
	            
	            String email = String.valueOf(claims.get("email"));
	            String authorities = String.valueOf(claims.get("authorities"));
	            
	            List<GrantedAuthority> auths = AuthorityUtils.commaSeparatedStringToAuthorityList(authorities);
	            Authentication authentication = new UsernamePasswordAuthenticationToken(email, null, auths);
	            SecurityContextHolder.getContext().setAuthentication(authentication);
	        } catch (Exception e) {
	            // ❌ DON'T THROW - Just skip (Spring Security handles 401)
	            // throw new BadCredentialsException("invalid token...");
	        }
	    }
	    
	    filterChain.doFilter(request, response);
	}
}
