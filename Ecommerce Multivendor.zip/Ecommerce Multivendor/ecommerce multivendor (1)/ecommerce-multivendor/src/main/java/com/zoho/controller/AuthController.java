package com.zoho.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.domain.USER_ROLE;
import com.zoho.modal.User;
import com.zoho.modal.VerificationCode;
import com.zoho.repository.UserRepository;
import com.zoho.request.LoginOtpRequest;
import com.zoho.request.LoginRequest;
import com.zoho.response.ApiResponse;
import com.zoho.response.AuthResponse;
import com.zoho.response.SignUpRequest;
import com.zoho.service.AuthService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

	private final UserRepository userRepository;
	private final AuthService authService;

	@PostMapping("/signup")
	public ResponseEntity<AuthResponse> createUserHamdler(@RequestBody SignUpRequest req) throws Exception {

		String jwt = authService.createUser(req);

		AuthResponse res = new AuthResponse();

		res.setJwt(jwt);
		res.setMessage("register success");
		res.setRole(USER_ROLE.ROLE_CUSTOMER);

		return ResponseEntity.ok(res);

	}

	@PostMapping("/sent/login-signup-otp")
	public ResponseEntity<ApiResponse> sentOtpHandler(@RequestBody LoginOtpRequest req) throws Exception {

		authService.sentLoginOtp(req.getEmail(),req.getRole());

		ApiResponse res = new ApiResponse();

		res.setMessage("otp sent  successfully");

		return ResponseEntity.ok(res);

	}
	
	@PostMapping("/signing")
	public ResponseEntity<AuthResponse> LoginHandler(@RequestBody LoginRequest req) throws Exception {

		AuthResponse authResponse=authService.signing(req);

		return ResponseEntity.ok(authResponse);

	}
}
