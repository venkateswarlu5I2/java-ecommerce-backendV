package com.zoho.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.response.ApiResponse;

@RestController
public class HomeController {
	
	@GetMapping("/")
	public ApiResponse HomeControllerHandler() {

	    ApiResponse apiResponse = new ApiResponse();
	    apiResponse.setMessage("welcome to the project");
	    return apiResponse;
	}



}
