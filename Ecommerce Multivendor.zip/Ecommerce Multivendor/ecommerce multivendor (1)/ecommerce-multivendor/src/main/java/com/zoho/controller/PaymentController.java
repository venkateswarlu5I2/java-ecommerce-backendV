package com.zoho.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.modal.Order;
import com.zoho.modal.PaymentOrder;
import com.zoho.modal.Seller;
import com.zoho.modal.SellerReport;
import com.zoho.modal.User;
import com.zoho.response.ApiResponse;
import com.zoho.response.PaymentLinkResponse;
import com.zoho.service.OrderService;
import com.zoho.service.PaymentService;
import com.zoho.service.SellerReportService;
import com.zoho.service.SellerService;
import com.zoho.service.TransactionService;
import com.zoho.service.UserService;

import lombok.RequiredArgsConstructor;





@RequiredArgsConstructor
@RestController
@RequestMapping("/api/payment")


public class PaymentController {
	
	private final PaymentService paymentService;
	private final  UserService    userService;
	
	private final SellerService  sellerService;
	
	private final SellerReportService sellerReportService;
	private final OrderService orderService;
	
	private final  TransactionService  transactionService;

    @GetMapping("/{paymentId}")
    public ResponseEntity<ApiResponse> paymentSuccessHandler(
            @PathVariable String paymentId,
            @RequestParam String paymentLinkId,
            @RequestHeader("Authorization") String jwt) throws Exception {

        User user = userService.findUserByJwtToken(jwt);

        PaymentLinkResponse paymentResponse;

        PaymentOrder paymentOrder= paymentService
                .getPaymentOrderByPaymentId(paymentLinkId);

        boolean paymentSuccess = paymentService.ProceedPaymentOrder(
                paymentOrder,
                paymentId,
                paymentLinkId
        );
        if(paymentSuccess){
            for(Order order:paymentOrder.getOrders()){
               transactionService.createTransaction(order);
                Seller seller=sellerService.getSellerById(order.getSellerId());
                SellerReport report=sellerReportService.getSellerReport(seller);
                report.setTotalOrders(report.getTotalOrders()+1);
                report.setTotalEarnings(report.getTotalEarnings()+order.getTotalSellingPrice());
                report.setTotalSales(report.getTotalSales()+order.getOrderItems().size());
                sellerReportService.updateSellerReport(report);
            }
           

        }
      
        ApiResponse res = new ApiResponse();
        res.setMessage("Payment successful");
       

        return new ResponseEntity<>(res, HttpStatus.CREATED);
    }
	
	
	
	

}
