package com.zoho.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.exceptions.ProductException;
import com.zoho.modal.Product;
import com.zoho.modal.Seller;
import com.zoho.request.CreateProductRequest;
import com.zoho.service.ProductService;
import com.zoho.service.SellerService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/sellers/product")

public class SellerProductController {
	
	private final  ProductService productService;
	
	private final SellerService sellerService;
	
	
	
	
	 @GetMapping()
	    public ResponseEntity<List<Product>> getProductBySellerId(
	            @RequestHeader("Authorization") String jwt) throws Exception {

	        Seller seller=sellerService.getSellerProfile(jwt);

	        List<Product> product = productService.getProductBySellerId(seller.getId());
	        return new ResponseEntity<>(product, HttpStatus.OK);

	    }

	    @PostMapping()
	    public ResponseEntity<Product> createProduct(
	            @RequestBody CreateProductRequest request,

	            @RequestHeader("Authorization")String jwt)
	            throws Exception {

	      Seller seller=sellerService.getSellerProfile(jwt);

	        Product product = productService.createProduct(request, seller);
	    	//Product product =new Product();
	        return new ResponseEntity<>(product, HttpStatus.CREATED);

	    }

	    @DeleteMapping("/{productId}")
	    public ResponseEntity<Void> deleteProduct(@PathVariable Long productId) {
	        try {
	            productService.deleteProduct(productId);
	            return new ResponseEntity<>(HttpStatus.OK);
	        } catch (ProductException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	    @PutMapping("/{productId}")
	    public ResponseEntity<Product> updateProduct(@PathVariable Long productId, @RequestBody Product product) 
	    	throws ProductException{
	       
	            Product updatedProduct = productService.updateProduct(productId, product);
	            return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
	       
	    }

	   
	    }



