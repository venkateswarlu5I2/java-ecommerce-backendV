package com.zoho.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.domain.USER_ROLE;
import com.zoho.modal.User;
import com.zoho.response.AuthResponse;
import com.zoho.response.SignUpRequest;
import com.zoho.service.UserService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class UserController {
	private final UserService userService;
	
	@GetMapping("/user/profile")
	public ResponseEntity<User> crateUserHandler(
			@RequestHeader("Authorization") String jwt) throws Exception{

		User user=userService.findUserByJwtToken(jwt);
		
		
		return ResponseEntity.ok(user);
	}
	

}
