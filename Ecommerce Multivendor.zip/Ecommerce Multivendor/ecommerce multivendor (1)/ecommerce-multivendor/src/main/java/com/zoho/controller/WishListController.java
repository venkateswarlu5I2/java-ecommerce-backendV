package com.zoho.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.modal.Product;
import com.zoho.modal.User;
import com.zoho.modal.WishList;
import com.zoho.service.ProductService;
import com.zoho.service.UserService;
import com.zoho.service.WishListService;

import jdk.jshell.spi.ExecutionControl.UserException;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/wishList")
public class WishListController {
	 
	
	private final WishListService wishlistService;
    private final ProductService productService;
    private final UserService userService;


   
    @GetMapping()
    public ResponseEntity<WishList> getWishlistByUserId(
            @RequestHeader("Authorization") String jwt) throws Exception  {

        User user = userService.findUserByJwtToken(jwt);
        WishList wishlist = wishlistService.getWishlistByUserId(user);
        return ResponseEntity.ok(wishlist);
    }

    @PostMapping("/add-product/{productId}")
    public ResponseEntity<WishList> addProductToWishlist(
            @PathVariable Long productId,
            @RequestHeader("Authorization") String jwt) throws Exception  {

        Product product = productService.findProductById(productId);
        User user=userService.findUserByJwtToken(jwt);
        WishList updatedWishlist = wishlistService.addProductToWishlist(
                user,
                product
        );
        return ResponseEntity.ok(updatedWishlist);

    }

}






