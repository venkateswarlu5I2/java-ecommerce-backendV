package com.zoho.domain;

public enum PaymentMethod {
	 RAZORPAY,
	    STRIPE
	

}
