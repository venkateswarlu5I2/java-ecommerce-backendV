package com.zoho.domain;

public enum PaymentOrderStatus {
	 PENDING,SUCCESS,FAILED

}
