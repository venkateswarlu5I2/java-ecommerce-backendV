package com.zoho.domain;

public enum PaymentStatus {
	

	PENDING,
    PROCESSING,
    COMPLETED,
    FAILED

}
