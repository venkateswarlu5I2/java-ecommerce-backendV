package com.zoho.exceptions;

public class SellerException extends Exception {

	
	public SellerException(String message) {
		super(message);
	}
	
}
