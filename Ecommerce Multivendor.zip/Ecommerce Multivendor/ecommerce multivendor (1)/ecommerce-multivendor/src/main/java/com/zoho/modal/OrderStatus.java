package com.zoho.modal;

public enum OrderStatus {
	PENDING,
	PLACED,
	CONFIRMED,
	SHIPPED,
	DELIVERED,
	CANCELLED

}
