package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Address;

public interface AddressRepository extends JpaRepository <Address,Long>{
	
	

}
