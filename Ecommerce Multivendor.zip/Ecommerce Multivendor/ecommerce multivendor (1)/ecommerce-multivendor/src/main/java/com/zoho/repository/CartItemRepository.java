 package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Cart;
import com.zoho.modal.CartItem;
import com.zoho.modal.Product;

public interface CartItemRepository extends JpaRepository<CartItem,Long>{
	
CartItem findByCartAndProductAndSize(Cart cart,Product product,String size);

	
	
}
