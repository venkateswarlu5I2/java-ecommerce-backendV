package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Cart;

public interface CartRepository extends  JpaRepository<Cart,Long>{

	Cart findByUserId(Long id);

}
