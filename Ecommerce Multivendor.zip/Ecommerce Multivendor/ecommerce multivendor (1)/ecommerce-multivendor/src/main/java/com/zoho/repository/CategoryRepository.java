package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Category;

public interface CategoryRepository  extends JpaRepository<Category,Long>{
	
	 Category findByCategoryId(String categoryId);
	

}
