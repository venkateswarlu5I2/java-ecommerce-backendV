package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Coupon;

public interface CouponRepository  extends JpaRepository<Coupon,Long> {
    Coupon findByCode(String Code);
	
	

}
