package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Deal;

public interface DealRepository extends JpaRepository<Deal,Long> {

}
