package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.HomeCategory;

public interface HomeCategoryRepository extends JpaRepository<HomeCategory,Long>{

}
