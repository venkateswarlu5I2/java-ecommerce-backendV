package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem ,Long>{

}
