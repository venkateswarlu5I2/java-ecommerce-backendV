package com.zoho.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Order;

public interface OrderRepository extends JpaRepository<Order, Long>{

	List<Order> findByUserId(Long userId);
	List<Order> findBySellerId(Long sellerId);
	
	
	
	
}
