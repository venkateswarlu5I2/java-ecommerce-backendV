package com.zoho.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.Review;

public interface ReviewRepository  extends JpaRepository<Review,Long> {
   // List<Review> findReviewsByUserId(Long userId);
    List<Review> findByProductId(Long productId); 
}
	
	


