package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.SellerReport;

public interface SellerReportRepository extends JpaRepository<SellerReport ,Long>{
	
SellerReport findBySellerId(Long sellerId);
}
