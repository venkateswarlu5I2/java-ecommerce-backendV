package com.zoho.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.domain.AccountStatus;
import com.zoho.modal.Seller;
import com.zoho.modal.SellerReport;

public interface SellerRepository  extends JpaRepository<Seller,Long> {
	
Seller findByEmail(String email);
List<Seller> findByAccountStatus(AccountStatus status);

}
