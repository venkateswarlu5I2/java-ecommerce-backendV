package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.User;

public interface UserRepository extends JpaRepository<User,Long> {
	
	User findByEmail(String email );

}
