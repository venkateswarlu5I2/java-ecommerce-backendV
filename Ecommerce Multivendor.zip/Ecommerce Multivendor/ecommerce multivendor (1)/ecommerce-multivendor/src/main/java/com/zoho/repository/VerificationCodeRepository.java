package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.VerificationCode;

public interface VerificationCodeRepository extends JpaRepository<VerificationCode,Long> {
	
VerificationCode findByEmail(String code);

VerificationCode findByOtp(String otp);
}
