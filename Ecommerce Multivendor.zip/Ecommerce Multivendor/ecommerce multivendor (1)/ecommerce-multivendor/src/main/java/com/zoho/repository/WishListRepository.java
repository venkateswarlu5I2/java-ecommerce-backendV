package com.zoho.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoho.modal.WishList;

public interface WishListRepository   extends JpaRepository<WishList, Long> {
    WishList findByUserId(Long userId);
}
