package com.zoho.response;

import lombok.Data;

@Data
public class ApiResponse {
	
	
	private String message;

}
