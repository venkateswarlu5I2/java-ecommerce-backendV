package com.zoho.service;

import com.zoho.domain.USER_ROLE;
import com.zoho.request.LoginRequest;
import com.zoho.response.AuthResponse;
import com.zoho.response.SignUpRequest;

public interface AuthService {
	
	void sentLoginOtp(String email,USER_ROLE role) throws Exception;
	
	String createUser(SignUpRequest req) throws Exception;
	
	AuthResponse signing(LoginRequest req) throws Exception;
	
	
	}
	


