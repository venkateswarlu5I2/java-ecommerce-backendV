package com.zoho.service;

import com.zoho.modal.Cart;
import com.zoho.modal.CartItem;
import com.zoho.modal.Product;
import com.zoho.modal.User;

public interface CartService {
	
	public CartItem addCartItem(User user,Product product,String size,int quantity);
		
		
		public Cart findUserCart(User user);
		
		
	}


