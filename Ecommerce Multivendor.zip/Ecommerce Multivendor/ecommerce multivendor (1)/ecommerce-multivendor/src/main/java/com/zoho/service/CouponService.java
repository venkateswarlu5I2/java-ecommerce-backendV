package com.zoho.service;

import java.util.List;

import com.zoho.modal.Cart;
import com.zoho.modal.Coupon;
import com.zoho.modal.User;

public interface CouponService {
	

	Cart applyCoupon(String code, double orderValue, User user) throws Exception;
    Cart removeCoupon(String code, User user) throws Exception;
    Coupon findCouponById(Long  Id) throws Exception;
    Coupon createCoupon(Coupon coupon);
    
    List<Coupon> findAllCoupons();
    void deleteCoupon(Long Id)throws Exception;
    
    
}
