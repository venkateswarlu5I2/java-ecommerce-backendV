package com.zoho.service;

import java.util.List;

import com.zoho.modal.HomeCategory;

public interface HomeCategoryService {
	HomeCategory createHomeCategory(HomeCategory homeCategories);
    List<HomeCategory> createCategories(List<HomeCategory> homeCategories);
    HomeCategory updateHomeCategory(HomeCategory homeCategories,Long id) throws Exception;
    List<HomeCategory> getAllHomeCategories();

}
