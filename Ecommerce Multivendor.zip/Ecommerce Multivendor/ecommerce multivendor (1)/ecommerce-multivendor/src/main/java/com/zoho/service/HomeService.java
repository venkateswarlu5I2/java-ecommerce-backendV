package com.zoho.service;

import java.util.List;

import com.zoho.modal.Home;
import com.zoho.modal.HomeCategory;

public interface HomeService {
public Home createHomePageData(List<HomeCategory> allCategories);

}
