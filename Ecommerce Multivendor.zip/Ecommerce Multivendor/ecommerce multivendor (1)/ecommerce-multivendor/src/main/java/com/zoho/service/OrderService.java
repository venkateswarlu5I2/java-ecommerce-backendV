package com.zoho.service;

import java.util.List;
import java.util.Set;

import com.zoho.modal.Address;
import com.zoho.modal.Cart;
import com.zoho.modal.Order;
import com.zoho.modal.OrderItem;
import com.zoho.modal.OrderStatus;
import com.zoho.modal.User;

public interface OrderService {

	Set<Order> createOrder(User user, Address shippingAddress, Cart cart);

	Order findOrderById(Long Id)throws Exception;

	List<Order> usersOrderHistory(Long userId);

	List<Order> sellersOrder(Long sellerId);

	Order updateOrderStatus(Long orderId, OrderStatus orderStatus) throws Exception;

	Order cancelOrder(Long orderId, User user)throws Exception;

	
	OrderItem getOrderItemById(Long id)throws Exception;
}
