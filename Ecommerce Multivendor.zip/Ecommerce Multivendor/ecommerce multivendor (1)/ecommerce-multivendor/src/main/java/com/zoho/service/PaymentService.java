package com.zoho.service;

import java.util.Set;

import com.razorpay.PaymentLink;
import com.razorpay.RazorpayException;
import com.stripe.exception.StripeException;
import com.zoho.modal.Order;
import com.zoho.modal.PaymentOrder;
import com.zoho.modal.User;

public interface PaymentService {
	

    PaymentOrder createOrder(User user,Set<Order> orders);

    PaymentOrder getPaymentOrderById(Long  orderId) throws Exception;

    PaymentOrder getPaymentOrderByPaymentId(String orderId) throws Exception;

    Boolean ProceedPaymentOrder (PaymentOrder paymentOrder,
                                 String paymentId, String paymentLinkId) throws RazorpayException;

    PaymentLink createRazorpayPaymentLink(User user,
                                          Long Amount,
                                          Long orderId)throws RazorpayException ;

    String createStripePaymentLink(User user, Long Amount,
                                            Long orderId) throws StripeException ;
}

	
	
	
	
	
	
	


