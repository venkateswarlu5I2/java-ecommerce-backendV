package com.zoho.service;

import java.util.List;


import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.zoho.exceptions.ProductException;
import com.zoho.modal.Product;
import com.zoho.modal.Seller;
import com.zoho.request.CreateProductRequest;

public interface ProductService  {
	
	public Product createProduct(CreateProductRequest req,Seller seller) throws ProductException;
	
	public void deleteProduct(Long productId) throws ProductException;
	
	public Product updateProduct(Long productId,Product product)  throws ProductException;
	
	Product findProductById(Long productId)throws ProductException;
	
	List<Product> searchProduct(String query);
	
	public Page<Product> getAllProduct(
			String category,
            String brand,
            String color,
            String size,
            Integer minPrice,
            Integer maxPrice,
            Integer minDiscount,
            String sort,
            String stock,
            Integer pageNumber);

			
	List<Product> getProductBySellerId(Long sellerId);
	
	
	
	
	
	
	
	

}
