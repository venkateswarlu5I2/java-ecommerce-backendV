package com.zoho.service;

import java.util.List;

import com.zoho.modal.Product;
import com.zoho.modal.Review;
import com.zoho.modal.User;
import com.zoho.request.CreateReviewRequest;

public interface ReviewService {

    Review createReview(CreateReviewRequest req,
                        User user,
                        Product product);

    List<Review> getReviewsByProductId(Long productId)throws Exception;

    Review updateReview(Long reviewId,
                        String reviewText,
                        double rating,
                        Long userId) throws Exception;


    void deleteReview(Long reviewId, Long userId) throws Exception;
    
    Review getReviewById(Long reviewId)throws Exception;

    

}
