package com.zoho.service;

import com.zoho.modal.Seller;
import com.zoho.modal.SellerReport;

public interface SellerReportService {

	SellerReport getSellerReport(Seller seller);
	
	SellerReport updateSellerReport(SellerReport sellerReport);
}
