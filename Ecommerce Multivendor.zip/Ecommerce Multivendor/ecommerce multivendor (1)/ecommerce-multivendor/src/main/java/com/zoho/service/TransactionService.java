package com.zoho.service;

import java.util.List;

import com.zoho.modal.Order;
import com.zoho.modal.Seller;
import com.zoho.modal.Transaction;

public interface TransactionService {
	
	
	 Transaction createTransaction(Order order);
	    List<Transaction> getTransactionBySeller(Seller seller);
	    List<Transaction>getAllTransactions();
	}
	


