package com.zoho.service;

import com.zoho.modal.User;

public interface UserService {
	 User findUserByJwtToken(String jwt) throws Exception;
	 User findUserByEmail(String email)  throws Exception ;
	

}
