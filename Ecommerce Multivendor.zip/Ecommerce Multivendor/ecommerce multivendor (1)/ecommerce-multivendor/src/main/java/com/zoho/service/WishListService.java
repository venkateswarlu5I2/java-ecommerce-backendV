package com.zoho.service;

import com.zoho.modal.Product;
import com.zoho.modal.User;
import com.zoho.modal.WishList;

public interface WishListService {

	

    WishList createWishlist(User user);

    WishList getWishlistByUserId(User user);

    WishList addProductToWishlist(User user, Product product) ;
}
