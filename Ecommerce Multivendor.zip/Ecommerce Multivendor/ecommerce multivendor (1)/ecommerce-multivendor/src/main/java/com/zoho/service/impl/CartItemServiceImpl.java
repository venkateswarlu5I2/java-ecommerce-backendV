package com.zoho.service.impl;

import org.springframework.stereotype.Service;

import com.zoho.modal.CartItem;
import com.zoho.modal.User;
import com.zoho.repository.CartItemRepository;
import com.zoho.repository.CartRepository;
import com.zoho.service.CartItemService;
import com.zoho.service.CartService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class  CartItemServiceImpl implements CartItemService {

	private final CartRepository cartRepository;
	private final CartItemRepository cartItemRepository;
	
	
	
	
	@Override
	public CartItem updateCartItem(Long userId, Long id, CartItem cartItem) throws Exception {

		CartItem item =findCartItemById(id);
		User cartItemUser=item.getCart().getUser();
		
		if(cartItemUser.getId().equals(userId)){
			item.setQuantity(cartItem.getQuantity());
			item.setMrpPrice(item.getQuantity()*item.getProduct().getMrpPrice());
			item.setSellingPrice(item.getQuantity()*item.getProduct().getSellingPrice());
			
			 return cartItemRepository.save(item);
			
		}
		throw new Exception("you can't update this cartaitem");
	}
	@Override
	public void removeCartItem(Long userId, Long cartItemId) throws Exception {
		CartItem item =findCartItemById(cartItemId);
		
		User cartItemUser=item.getCart().getUser();
		
		if(cartItemUser.getId().equals(userId)){
			
		cartItemRepository.delete(item);
	}
		else throw new Exception("you can't delete this item");
	}
		
	@Override
	public CartItem findCartItemById(Long id) throws Exception {
		return  cartItemRepository.findById(id).orElseThrow(()->
		new Exception("cart item not found with id "+id));
	}
	
	
	
	

}
