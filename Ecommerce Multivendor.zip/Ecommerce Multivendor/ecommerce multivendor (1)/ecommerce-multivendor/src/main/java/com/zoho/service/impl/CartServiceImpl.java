package com.zoho.service.impl;

import org.springframework.stereotype.Service;

import com.zoho.modal.Cart;
import com.zoho.modal.CartItem;
import com.zoho.modal.Product;
import com.zoho.modal.User;
import com.zoho.repository.CartItemRepository;
import com.zoho.repository.CartRepository;
import com.zoho.service.CartService;

import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class CartServiceImpl implements CartService{
	
	

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;


	@Override
	public CartItem addCartItem(User user, Product product, String size, int quantity) {
		
		
		Cart cart=findUserCart(user);
		
		CartItem isPresent=cartItemRepository.findByCartAndProductAndSize(cart, product, size);
		
		if(isPresent==null) {
			CartItem cartItem=new CartItem();
			cartItem.setProduct(product);
			cartItem.setQuantity(quantity);
			cartItem.setUserId(user.getId());
			cartItem.setSize(size);
			
			int totalPrice=quantity* product.getSellingPrice();
			cartItem.setSellingPrice(totalPrice);
			
			cartItem.setMrpPrice(quantity*product.getMrpPrice());
			cartItem.setCart(cart);
			
			cartItemRepository.save(cartItem);
			
		}
		
		
		return isPresent;
	}

	@Override
	public Cart findUserCart(User user) {
		
		 Cart cart =cartRepository.findByUserId(user.getId());
		 
		 int totalPrice=0;
		 
		 int totalDiscountedPrice=0;
		 
		 int totalItem=0;
		 
		 
		for(CartItem cartItem: cart.getCartItems()) {
			 totalPrice+=cartItem.getMrpPrice();
			 
			 totalDiscountedPrice+=cartItem.getSellingPrice();
			 
			 totalItem+=cartItem.getQuantity();
			 
			 
			 
	
			
		}
		cart.setTotalMrpPrice(totalPrice);
		
		cart.setTotalItem(totalItem);
		
		cart.setTotalSellingPrice(totalDiscountedPrice);;
		
		cart.setDiscount(calclateDiscountPercentage(totalPrice,totalDiscountedPrice ));
		
		cart.setTotalItem(totalItem);
		
		
		
		
		
		
		
		return cart;
	}
	
	private int calclateDiscountPercentage(int mrpPrice, int sellingPrice) {

		if (mrpPrice <= 0) {
       return 0;
		}

		double discount = mrpPrice - sellingPrice;
		double discountPercentage = (discount / mrpPrice) * 100;

		return (int) discountPercentage;

	}
	}


	
	



