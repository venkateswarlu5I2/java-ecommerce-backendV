package com.zoho.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zoho.modal.HomeCategory;
import com.zoho.repository.HomeCategoryRepository;
import com.zoho.service.HomeCategoryService;

import lombok.RequiredArgsConstructor;



@Service
@RequiredArgsConstructor
public class HomeCategoryServiceInpl implements HomeCategoryService {

	
	
	 private final HomeCategoryRepository homeCategoryRepository;


	@Override
	public HomeCategory createHomeCategory(HomeCategory homecategories) {
		
		  return homeCategoryRepository.save(homecategories);
	}

	@Override
	public List<HomeCategory> createCategories(List<HomeCategory> homecategories) {
		 if (homeCategoryRepository.findAll().isEmpty()) {
	            return homeCategoryRepository.saveAll(homecategories);
	        }
	        return homeCategoryRepository.findAll();
	    }
	

	@Override
	public HomeCategory updateHomeCategory(HomeCategory category, Long id) throws Exception {
		
		 HomeCategory existingCategory = homeCategoryRepository.findById(id)
	                .orElseThrow(() -> new Exception("Category not found"));
	        if(category.getImage()!=null){
	            existingCategory.setImage(category.getImage());
	        }
	        if(category.getCategoryId()!=null){
	            existingCategory.setCategoryId(category.getCategoryId());
	        }
	        return homeCategoryRepository.save(existingCategory);
	    }

	

	@Override
	public List<HomeCategory> getAllHomeCategories() {
		return homeCategoryRepository.findAll();
	}

}
