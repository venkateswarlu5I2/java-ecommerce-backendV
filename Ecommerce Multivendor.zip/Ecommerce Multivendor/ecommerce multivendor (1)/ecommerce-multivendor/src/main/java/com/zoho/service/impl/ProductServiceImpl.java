package com.zoho.service.impl;

import java.awt.print.Pageable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.zoho.exceptions.ProductException;
import com.zoho.modal.Category;
import com.zoho.modal.Product;
import com.zoho.modal.Seller;
import com.zoho.repository.CategoryRepository;
import com.zoho.repository.ProductRepository;
import com.zoho.request.CreateProductRequest;
import com.zoho.service.ProductService;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

	private final ProductRepository productRepository;

	private final CategoryRepository categoryRepository;

	@Override
	public Product createProduct(CreateProductRequest req, Seller seller) {
		Category category1 = categoryRepository.findByCategoryId(req.getCategory());
		if (category1 == null) {
			Category category = new Category();
			category.setCategoryId(req.getCategory());
			category.setLevel(1);
			category1 = categoryRepository.save(category);

		}

		Category category2 = categoryRepository.findByCategoryId(req.getCategory());
		if (category2 == null) {
			Category category = new Category();
			category.setCategoryId(req.getCategory2());
			category.setLevel(2);
			category.setParentCategory(category1);

			category2 = categoryRepository.save(category);

		}
		Category category3 = categoryRepository.findByCategoryId(req.getCategory());

		if (category3 == null) {
			Category category = new Category();
			category.setCategoryId(req.getCategory3());
			category.setLevel(3);
			category.setParentCategory(category2);

			category3 = categoryRepository.save(category);

		}

		int discountPercentage = calclateDiscountPercentage(req.getMrpPrice(), req.getSellingPrice());

		Product product = new Product();
		product.setSeller(seller);
		product.setCategory(category3);
		product.setDescription(req.getDescription());
		product.setCreatedAt(LocalDateTime.now());
		product.setTitle(req.getTitle());
		product.setColor(req.getColor());
		product.setSellingPrice(req.getSellingPrice());
		product.setMrpPrice(req.getMrpPrice());
		product.setSize(req.getSize());
		product.setImages(req.getImages());
		product.setDiscountPercent(discountPercentage);

		return productRepository.save(product);

	}

	private int calclateDiscountPercentage(int mrpPrice, int sellingPrice) {

		if (mrpPrice <= 0) {
			throw new IllegalArgumentException("Actual price must be greater than 0");

		}

		double discount = mrpPrice - sellingPrice;
		double discountPercentage = (discount / mrpPrice) * 100;

		return (int) discountPercentage;

	}

	@Override
	public void deleteProduct(Long productId) throws ProductException {
		Product product = findProductById(productId);
		productRepository.delete(product);

	}

	@Override
	public Product updateProduct(Long productId, Product product) throws ProductException {
		findProductById(productId);
		product.setId(productId);

		return productRepository.save(product);
	}

	@Override
	public Product findProductById(Long productId) throws ProductException {

		return productRepository.findById(productId)
				.orElseThrow(() -> new ProductException("product not found with id " + productId));
	}

	@Override
	public List<Product> searchProduct(String query) {
		 
		return productRepository.searchProduct(query);
	}

	@Override
	public Page<Product> getAllProduct(String category, String brand, String color, String size, Integer minPrice,
	        Integer maxPrice, Integer minDiscount, String sort, String stock, Integer pageNumber) {
	    
	    Specification<Product> spec = (root, query, criteriaBuilder) -> {
	        List<Predicate> predicates = new ArrayList<>();

	        if (category != null) {
	            Join<Product, Category> categoryJoin = root.join("category");
	            predicates.add(criteriaBuilder.equal(categoryJoin.get("categoryId"), category));
	        }

	        if (color != null && !color.isEmpty()) {
	            predicates.add(criteriaBuilder.equal(root.get("color"), color));
	        }

	        if (size != null && !size.isEmpty()) {
	            predicates.add(criteriaBuilder.equal(root.get("size"), size));
	        }

	        if (minPrice != null) {
	            predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("sellingPrice"), minPrice));
	        }

	        if (maxPrice != null) {
	            predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("sellingPrice"), maxPrice));
	        }

	        if (minDiscount != null) {
	            predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("discountPercent"), minDiscount));
	        }

	        if (stock != null) {
	            // Make sure your Product model has 'in_stock' or 'stock' field correctly
	            predicates.add(criteriaBuilder.equal(root.get("in_stock"), stock.equalsIgnoreCase("in_stock")));
	        }

	        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
	    };

	    // Correcting the Import and PageRequest
	    org.springframework.data.domain.Pageable pageable; 
	    int page = (pageNumber != null) ? pageNumber : 0;
	    int pageSize = 10; // Set a default page size

	    if (sort != null && !sort.isEmpty()) {
	        pageable = switch (sort) {
	            case "price_low" -> PageRequest.of(page, pageSize, Sort.by("sellingPrice").ascending());
	            case "price_high" -> PageRequest.of(page, pageSize, Sort.by("sellingPrice").descending());
	            default -> PageRequest.of(page, pageSize, Sort.unsorted());
	        };
	    } else {
	        pageable = PageRequest.of(page, pageSize, Sort.unsorted());
	    }

	    return productRepository.findAll(spec, pageable);
	} // Missing bracket ikkade!
	@Override
	public List<Product> getProductBySellerId(Long sellerId) {
		return productRepository.findBySellerId(sellerId);
	}

}
