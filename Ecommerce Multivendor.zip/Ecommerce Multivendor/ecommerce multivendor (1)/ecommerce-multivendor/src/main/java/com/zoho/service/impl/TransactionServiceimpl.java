package com.zoho.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zoho.modal.Order;
import com.zoho.modal.Seller;
import com.zoho.modal.Transaction;
import com.zoho.repository.SellerRepository;
import com.zoho.repository.TransactionRepository;
import com.zoho.service.TransactionService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor

public class TransactionServiceimpl implements TransactionService {

	
	
	

    private final TransactionRepository transactionRepository;
    private final SellerRepository sellerRepository;
	
	@Override
	public Transaction createTransaction(Order order) {
		Seller seller=sellerRepository.findById(order.getSellerId()).get();
		
		Transaction transaction=new Transaction();
		transaction.setSeller(seller);
		transaction.setCustomer(order.getUser());
		transaction.setOrder(order);
		
		
		return transactionRepository.save(transaction);
	}

	@Override
	public List<Transaction> getTransactionBySeller(Seller seller) {
		
		return transactionRepository.findBySellerId(seller.getId());
	}

	@Override
	public List<Transaction> getAllTransactions() {
		
		
		
		return transactionRepository.findAll();
	}

}
