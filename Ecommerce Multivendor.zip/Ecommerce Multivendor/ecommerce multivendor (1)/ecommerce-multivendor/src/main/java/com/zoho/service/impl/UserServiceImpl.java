package com.zoho.service.impl;

import org.springframework.stereotype.Service;

import com.zoho.config.JwtProvider;
import com.zoho.modal.User;
import com.zoho.repository.UserRepository;
import com.zoho.service.UserService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
	private final UserRepository userRepository;
	private final JwtProvider jwtProvider;

	@Override
	public User findUserByJwtToken(String jwt) throws Exception {
		String email = jwtProvider.getEmailFromJwtToken(jwt);

		return this.findUserByEmail(email);

	}

	@Override
	public User findUserByEmail(String email) throws Exception {
     User user=userRepository.findByEmail(email);
		
		if(user==null) {
	    throw new Exception("user not  with username- "+email);
	}
		
		return user;

}
}
