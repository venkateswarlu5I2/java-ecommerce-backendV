package com.zoho.service.impl;

import org.springframework.stereotype.Service;

import com.zoho.modal.Product;
import com.zoho.modal.User;
import com.zoho.modal.WishList;
import com.zoho.repository.WishListRepository;
import com.zoho.service.WishListService;

import lombok.RequiredArgsConstructor;



@Service
@RequiredArgsConstructor
public class WishListServiceImpl   implements  WishListService{
	
	private final   WishListRepository  wishListRepository ;
		
	
	

	@Override
	public WishList createWishlist(User user) {
		WishList wishlist = new WishList();
        wishlist.setUser(user);
        return wishListRepository.save(wishlist);
	}

	@Override
	public WishList getWishlistByUserId(User user) {
		 WishList wishlist = wishListRepository.findByUserId(user.getId());
	        if (wishlist == null) {
	            wishlist = this.createWishlist(user);
	        }
	        return wishlist;
		
	}

	@Override
	public WishList addProductToWishlist(User user, Product product) {
		WishList wishlist = this.getWishlistByUserId(user);
        if(wishlist.getProducts().contains(product)){
            wishlist.getProducts().remove(product);
        }
        else wishlist.getProducts().add(product);

        return wishListRepository.save(wishlist);
    }
		

}
